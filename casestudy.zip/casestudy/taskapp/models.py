from django.db import models

# Create your models here.

class Insurance(models.Model):
    customer = models.CharField(max_length=100, null=True)
    insurance = models.CharField(max_length=100, null=True)
    value = models.FloatField(default=0)
    rate = models.FloatField(default=0)
    # premium = models.FloatField(default=0)

    @property
    def premium(self):
        return self.value*self.rate
