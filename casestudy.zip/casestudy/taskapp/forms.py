from django.forms import ModelForm
from django import forms

from .models import Insurance

class InsuranceUpdate(ModelForm):
    class Meta:
        model = Insurance
        fields = '__all__'