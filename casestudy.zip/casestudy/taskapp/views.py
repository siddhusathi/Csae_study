from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from .models import Insurance
from .forms import InsuranceUpdate

# Create your views here.
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.info(request, "Username OR Password is incorrect.")

    return render(request, 'taskapp/login.html')

def logoutPage(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def home(request):
    context = {}
    return render(request, 'taskapp/home.html', context)

@login_required(login_url='login')
def dashboard(request):
    insurenc = Insurance.objects.all()
    context = {
        'insurenc':insurenc
    }
    return render(request, 'taskapp/dashboard.html', context)

@login_required(login_url='login')
def update(request, pk):
    insurenc = Insurance.objects.get(id=pk)

    form = InsuranceUpdate(instance=insurenc)
    if request.method == 'POST':
        form = InsuranceUpdate(request.POST, instance=insurenc)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
        else:
            messages.info(request, 'Update got errors.')

    context = {
        'form':form
    }
    return render(request, 'taskapp/update.html', context)
